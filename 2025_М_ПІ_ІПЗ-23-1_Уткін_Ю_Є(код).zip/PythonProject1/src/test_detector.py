# src/test_detector.py

import os
import sys
import cv2
import argparse


src_dir = os.path.dirname(os.path.abspath(__file__))
if src_dir not in sys.path:
    sys.path.insert(0, src_dir)

from detection.yolo_detector import YoloDetector

def main():
    parser = argparse.ArgumentParser(
        description='Test YOLO detector on video file or camera'
    )
    parser.add_argument(
        '--source',
        default=r'C:\Users\bogac\PycharmProjects\PythonProject1\data\Test1_tree_human_run.mp4',
        help='шлях до відеофайлу або номер камери (0,1,...)'
    )
    parser.add_argument(
        '--conf', type=float, default=0.3,
        help='поріг довіри для детекції'
    )
    parser.add_argument(
        '--iou', type=float, default=0.45,
        help='поріг NMS (IoU)'
    )
    args = parser.parse_args()

    # ───────────── DIAGNOSTICS ─────────────
    print("=== DIAGNOSTICS ===")
    print("Source       :", args.source)
    print("Exists       :", os.path.exists(args.source))
    print("Is file      :", os.path.isfile(args.source))

    cap = cv2.VideoCapture(args.source)
    print("cap.isOpened():", cap.isOpened())


    ret, frame = cap.read()
    print("First frame read:", ret)
    if not ret:
        print("Не вдалося прочитати жодного кадру. Перевірте шлях та кодеки.")
        return


    cap.release()
    cap = cv2.VideoCapture(args.source)
    print("=== END DIAGNOSTICS ===\n")
    # ────────────────────────────────────────


    det = YoloDetector(conf_thres=args.conf, iou_thres=args.iou)

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        dets = det.detect(frame)
        for x1, y1, x2, y2, conf in dets:
            cv2.rectangle(
                frame,
                (int(x1), int(y1)),
                (int(x2), int(y2)),
                (0, 255, 0), 2
            )
            cv2.putText(
                frame,
                f"{conf:.2f}",
                (int(x1), int(y1) - 5),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.5, (0, 255, 0), 1
            )

        cv2.imshow('YOLO Test', frame)
        if cv2.waitKey(1) & 0xFF == 27:  # ESC
            break

    cap.release()
    cv2.destroyAllWindows()

if __name__ == '__main__':
    main()
