from deep_sort_realtime.deepsort_tracker import DeepSort

class DeepSortTracker:
    def __init__(
        self,
        max_iou_distance: float    = 0.7,   # зменшили, щоб більше прив’язувало по руху
        max_age: int               = 30,    # тепер трек живе 30 кадрів без детекції
        n_init: int                = 1,     # підтверджуємо трек вже після 1 детекції
        max_cosine_distance: float = 0.5,   # трохи послабили appearance-поріг
        nms_max_overlap: float     = 1.0,   # майже без NMS
        half: bool                 = True,  # FP16-режим для пришвидшення, якщо є GPU
        use_appearance: bool       = True  # якщо False — вмикаємо тільки IOU + Kalman
    ):
        """
        :param max_iou_distance: IoU-поріг для spatial association
        :param max_age: скільки кадрів без нових bbox трек залишається живим
        :param n_init: кількість підтверджень, щоб вважати трек активним
        :param max_cosine_distance: appearance-threshold (ігнорується, якщо use_appearance=False)
        :param nms_max_overlap: NMS-threshold перед асоціацією
        :param half: використовувати FP16 фічі
        :param use_appearance: False → зовсім не вийматимемо appearance-фічі, тільки IOU
        """
        # якщо нам не потрібна appearance-частина, просто передаємо embedder=None
        if not use_appearance:
            self.tracker = DeepSort(
                max_iou_distance    = max_iou_distance,
                max_age             = max_age,
                n_init              = n_init,
                nms_max_overlap     = nms_max_overlap,
                embedder            = None,    # не виймати фічі
                half                = half
            )
        else:
            self.tracker = DeepSort(
                max_iou_distance    = max_iou_distance,
                max_age             = max_age,
                n_init              = n_init,
                max_cosine_distance = max_cosine_distance,
                nms_max_overlap     = nms_max_overlap,
                half                = half
            )

    def update_tracks(self, ds_inputs, frame=None):
        """
        МИ ОБОВ’ЯЗКОВО КОЖЕН КАДР КАРТИМО трекер, навіть якщо ds_inputs == []
        (його Kalman-фільтр зробить predict)
        """
        # передаємо всім: або координати нових bbox, або пустий список
        tracks = self.tracker.update_tracks(ds_inputs, frame=frame)
        # повертаємо тільки підтверджені (confirmed) треки
        return [t for t in tracks if t.is_confirmed()]
