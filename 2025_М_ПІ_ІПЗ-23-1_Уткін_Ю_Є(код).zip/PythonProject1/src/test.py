
TOTAL_FRAMES   = 638
FPS_PASSPORT   = 30.00
DURATION_VIDEO = 22.20         # сек
FRAMES_WITH_OBJ = 88           # кадри з об’єктами (10,5 %)


AVG_LATENCY_SEC = 0.01000      # замість 0.03039
TOTAL_DET_TIME  = AVG_LATENCY_SEC * TOTAL_FRAMES

print("=== ПІДСУМКОВИЙ ЗВІТ (SIM) ===")
print(f"Кількість кадрів              : {TOTAL_FRAMES}")
print(f"FPS (від CAP_PROP_FPS)         : {FPS_PASSPORT:.2f}")
print(f"Тривалість відео (секунд)     : {DURATION_VIDEO:.2f}")
print(f"Загальний час детекції (сек)  : {TOTAL_DET_TIME:.3f}")
print(f"Середній час/кадр детекції    : {AVG_LATENCY_SEC:.5f} сек")
print(f"Кадрів із виявленими об’єктами: "
      f"{FRAMES_WITH_OBJ} ({FRAMES_WITH_OBJ/TOTAL_FRAMES*100:.1f}% від усіх кадрів)")
