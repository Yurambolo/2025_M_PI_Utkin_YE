# src/main.py

import os
import sys
import argparse
import cv2


proj = os.path.dirname(__file__)
if proj not in sys.path:
    sys.path.insert(0, proj)

from detection.yolo_detector import YoloDetector
from tracking.deep_sort_tracker import DeepSortTracker


from PX4_command_generator import compute_yaw_correction, generate_px4_commands

def main():
    p = argparse.ArgumentParser(description='YOLO→DeepSORT із PX4-командами')
    p.add_argument('--source', default=0,  help='відео або індекс камери')
    p.add_argument('--model',  default='yolov8n.pt', help='файл ваг YOLO')
    p.add_argument('--conf',   type=float, default=0.2,  help='confidence-поріг')
    p.add_argument('--iou',    type=float, default=0.45, help='IoU-поріг')
    p.add_argument('--hfov',   type=float, default=90.0, help='горизонтальний FOV°')
    p.add_argument('--kp',     type=float, default=0.5,  help='P-коефіцієнт yaw')
    p.add_argument('--speed',  type=float, default=5.0,  help='швидкість вперед, м/с')
    args = p.parse_args()

    cap = cv2.VideoCapture(args.source)
    if not cap.isOpened():
        print(f"❌ Не вдалося відкрити: {args.source}")
        return

    detector = YoloDetector(
        model_path = args.model,
        conf_thres = args.conf,
        iou_thres  = args.iou
    )
    tracker = DeepSortTracker(
        max_iou_distance    = 1.0,
        max_age             = 30,
        n_init              = 1,
        max_cosine_distance = 0.4,
        nms_max_overlap     = 0.8,
        half                = True
    )

    STATE_IDLE, STATE_TRACKING = 0, 1
    state = STATE_IDLE
    active_track = None

    frame_w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    frame_h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        # 1) детекція
        raw = detector.detect(frame)
        people = [d for d in raw if d[4]>=args.conf and d[5]==0]

        # 2) підготовка до трекінгу
        if people and state==STATE_IDLE:
            x1,y1,x2,y2,conf,cls = max(people, key=lambda x: x[4])
            ds_inputs = [([x1,y1,x2-x1,y2-y1], conf)]
        elif state==STATE_TRACKING:
            ds_inputs = [
              ([x1,y1,x2-x1,y2-y1], conf)
              for x1,y1,x2,y2,conf,cls in people
            ]
        else:
            ds_inputs = []

        tracks = tracker.update_tracks(ds_inputs, frame=frame)

        # 3) FSM-transition
        if state==STATE_IDLE and tracks:
            active_track = tracks[0].track_id
            state = STATE_TRACKING
        elif state==STATE_TRACKING:
            if not any(t.track_id==active_track for t in tracks):
                state = STATE_IDLE
                active_track = None

        # 4) візуалізація боксу YOLO
        for x1,y1,x2,y2,conf,cls in people:
            cv2.rectangle(frame,(int(x1),int(y1)),(int(x2),int(y2)),(0,255,0),2)

        # 5) візуалізація треків
        for tr in tracks:
            tx1,ty1,tx2,ty2 = tr.to_ltrb()
            col = (255,0,0) if tr.track_id==active_track else (128,128,128)
            cv2.rectangle(frame,(int(tx1),int(ty1)),(int(tx2),int(ty2)),col,2)
            cv2.putText(frame,f"ID:{tr.track_id}",(int(tx1),int(ty1)-5),
                        cv2.FONT_HERSHEY_SIMPLEX,0.5,col,1)

        # 6) якщо трек активний — крім стрілок, генеруємо PX4–команди:
        if state==STATE_TRACKING and active_track is not None:
            tr = next(t for t in tracks if t.track_id==active_track)
            tx1,ty1,tx2,ty2 = tr.to_ltrb()
            # 6.1) розрахунок yaw-помилки й швидкості
            yaw_err, yaw_rate = compute_yaw_correction(
                tx1, ty1, tx2, ty2,
                frame_width=frame_w,
                hfov=args.hfov,
                kp=args.kp
            )
            # 6.2) вивід MAVLink-рядків у консоль
            generate_px4_commands(yaw_rate, args.speed)

            # 6.3) малюємо стрілочку
            img_cx = frame_w/2
            box_cx = (tx1+tx2)/2
            y_arrow = frame_h-40
            cv2.line(frame,(int(img_cx),0),(int(img_cx),frame_h),(255,255,255),1)
            cv2.arrowedLine(frame,
                            (int(img_cx),y_arrow),
                            (int(box_cx),y_arrow),
                            (0,255,0),3,tipLength=0.2)
            cv2.putText(frame,
                        f"YawErr {yaw_err:+.1f}°",
                        (10,30),cv2.FONT_HERSHEY_SIMPLEX,0.7,(0,255,0),2)

        # 7) показ
        cv2.imshow('YOLO→DeepSORT→PX4', frame)
        if cv2.waitKey(1)&0xFF==27:
            break

    cap.release()
    cv2.destroyAllWindows()

if __name__=='__main__':
    main()
