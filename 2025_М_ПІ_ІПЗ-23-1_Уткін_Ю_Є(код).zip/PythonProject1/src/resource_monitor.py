#!/usr/bin/env python3
import sys
import time
import subprocess
import psutil

def get_gpu_mem(pid: int) -> float:
    try:
        out = subprocess.check_output([
            "nvidia-smi",
            "--query-compute-apps=pid,used_memory",
            "--format=csv,noheader,nounits"
        ], encoding="utf-8")
        for line in out.strip().splitlines():
            proc_pid, mem = [x.strip() for x in line.split(",")]
            if int(proc_pid) == pid:
                return float(mem)
    except Exception:
        pass
    return 0.0

def main():
    if len(sys.argv) < 2:
        print("Usage: resource_monitor.py <command> [args…]")
        sys.exit(1)

    # Стартуємо ваш процес
    cmd = sys.argv[1:]
    proc = subprocess.Popen(cmd)
    ps_proc = psutil.Process(proc.pid)

    # Ініціалізуємо змінні для CPU-таймів, RSS і GPU-метрики
    start_times = ps_proc.cpu_times()
    last_times  = start_times
    peak_rss    = ps_proc.memory_info().rss
    peak_gpu    = get_gpu_mem(proc.pid)

    print(f"Запущено PID={proc.pid}: {' '.join(cmd)}")
    try:
        # Збираємо в циклі, поки процес живий
        while proc.poll() is None:
            # фіксуємо останні CPU-тайми
            try:
                last_times = ps_proc.cpu_times()
            except psutil.NoSuchProcess:
                break

            # пікове RSS
            rss = ps_proc.memory_info().rss
            if rss > peak_rss:
                peak_rss = rss

            # пікове GPU-споживання
            gpu_mem = get_gpu_mem(proc.pid)
            if gpu_mem > peak_gpu:
                peak_gpu = gpu_mem

            time.sleep(1)
    except KeyboardInterrupt:
        proc.terminate()
    finally:
        # Обчислюємо різницю таймів
        user_cpu  = last_times.user   - start_times.user
        sys_cpu   = last_times.system - start_times.system
        total_cpu = user_cpu + sys_cpu

        # Якщо процес ще живий — завершуємо його
        if proc.poll() is None:
            proc.terminate()

        # Виводимо абсолютні метрики
        print("\n=== Resource Usage Summary ===")
        print(f"CPU time  — user: {user_cpu:.2f}s, system: {sys_cpu:.2f}s, total: {total_cpu:.2f}s")
        print(f"RAM peak  — {peak_rss / 1024**2:.1f} MiB")
        # GPU-метрика буде >0 лише якщо процес дійсно використовував GPU
        print(f"GPU mem peak — {peak_gpu:.1f} MiB")

if __name__ == "__main__":
    # Pip-залежності: psutil
    # Якщо хочете GPU-метрики через python, додайте GPUtil, і замість nvidia-smi використайте:
    # import GPUtil; GPUtil.getGPUs()[i].memoryUsed
    main()
