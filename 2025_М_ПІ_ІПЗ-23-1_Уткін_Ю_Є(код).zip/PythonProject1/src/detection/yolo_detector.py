# src/detection/yolo_detector.py

import torch

# Монкі-патч для гарного і повного завантаження ваг через torch.load
_orig_torch_load = torch.load
def _torch_load_no_weights_only(f, *args, **kwargs):
    kwargs['weights_only'] = False
    return _orig_torch_load(f, *args, **kwargs)
torch.load = _torch_load_no_weights_only

from ultralytics import YOLO

class YoloDetector:
    def __init__(self, model_path='yolov8n.pt', conf_thres=0.25, iou_thres=0.45, device=None):
        self.device = device or ('cuda' if torch.cuda.is_available() else 'cpu')
        self.model = YOLO(model_path)
        self.model.to(self.device)
        self.model.fuse()
        self.conf_thres = conf_thres
        self.iou_thres  = iou_thres

    def detect(self, frame):
        results = self.model.predict(
            source=frame, conf=self.conf_thres, iou=self.iou_thres,
            device=self.device, verbose=False
        )
        r = results[0]
        boxes = r.boxes.xyxy.cpu().numpy()    # (N,4)
        confs = r.boxes.conf.cpu().numpy()    # (N,)
        clss  = r.boxes.cls.cpu().numpy().astype(int)  # (N,)

        dets = []
        for (x1,y1,x2,y2), conf, cls in zip(boxes, confs, clss):
            dets.append([float(x1),float(y1),float(x2),float(y2),float(conf),int(cls)])
        return dets
