# src/detect_timing.py

import os
import sys
import time
import cv2
import argparse

src_dir = os.path.dirname(os.path.abspath(__file__))
if src_dir not in sys.path:
    sys.path.insert(0, src_dir)

from detection.yolo_detector import YoloDetector

def main():
    parser = argparse.ArgumentParser(
        description='Вимірювання часу детекції з YOLO, підрахунок кадрів і кадрів з детекціями'
    )
    parser.add_argument(
        '--source',
        default=r'C:\Users\bogac\PycharmProjects\PythonProject1\data\Test1_tree_human_run.mp4',
        help='шлях до відеофайлу або номер камери (0,1,...)'
    )
    parser.add_argument(
        '--conf', type=float, default=0.3,
        help='поріг довіри для детекції'
    )
    parser.add_argument(
        '--iou', type=float, default=0.45,
        help='поріг NMS (IoU)'
    )
    args = parser.parse_args()

    print("=== DIAGNOSTICS ===")
    print("Source       :", args.source)
    print("Exists       :", os.path.exists(args.source))
    print("Is file      :", os.path.isfile(args.source))

    cap = cv2.VideoCapture(args.source)
    print("cap.isOpened():", cap.isOpened())
    ret, _ = cap.read()
    print("First frame read:", ret)
    if not ret:
        print("Не вдалося прочитати жодного кадру.")
        return

    cap.release()
    cap = cv2.VideoCapture(args.source)
    print("=== END DIAGNOSTICS ===\n")

    det = YoloDetector(conf_thres=args.conf, iou_thres=args.iou)

    total_det_time = 0.0
    frames_with_object = 0
    per_frame_stats = []

    frame_idx = 0
    fps = cap.get(cv2.CAP_PROP_FPS) or 30.0

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        start_det = time.perf_counter()
        dets = det.detect(frame)
        end_det = time.perf_counter()

        det_time = end_det - start_det
        total_det_time += det_time

        if len(dets) > 0:
            frames_with_object += 1

        for x1, y1, x2, y2, conf in dets:
            cv2.rectangle(
                frame,
                (int(x1), int(y1)),
                (int(x2), int(y2)),
                (0, 255, 0), 2
            )
            cv2.putText(
                frame,
                f"{conf:.2f}",
                (int(x1), int(y1) - 5),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.5, (0, 255, 0), 1
            )

        cv2.imshow('YOLO Detection Timing', frame)
        if cv2.waitKey(1) & 0xFF == 27:  # ESC
            break

        per_frame_stats.append((frame_idx, det_time))

        frame_idx += 1

    cap.release()
    cv2.destroyAllWindows()

    total_frames = frame_idx
    duration_video_sec = total_frames / fps
    total_time = total_det_time

    print("\n=== ПІДСУМКОВИЙ ЗВІТ ===")
    print(f"Кількість кадрів              : {total_frames}")
    print(f"FPS (від CAP_PROP_FPS)         : {fps:.2f}")
    print(f"Тривалість відео (секунд)     : {duration_video_sec:.2f}")
    print(f"Загальний час детекції (сек)  : {total_det_time:.3f}")
    print(f"Середній час/кадр детекції    : {total_det_time/total_frames:.5f} сек")
    print(f"Кадрів із виявленими об’єктами: {frames_with_object} ({frames_with_object/total_frames*100:.1f}% від усіх кадрів)")

if __name__ == '__main__':
    main()
