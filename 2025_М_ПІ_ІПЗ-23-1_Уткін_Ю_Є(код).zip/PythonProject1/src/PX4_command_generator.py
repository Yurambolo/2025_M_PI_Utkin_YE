import math
def compute_yaw_correction(x1: float, y1: float, x2: float, y2: float,
                           frame_width: int, hfov: float, kp: float) -> tuple[float, float]:
    box_cx = (x1 + x2) / 2.0
    img_cx = frame_width / 2.0
    dx = box_cx - img_cx
    yaw_error = (dx / frame_width) * hfov
    yaw_rate = kp * yaw_error
    return yaw_error, yaw_rate
def generate_px4_commands(yaw_rate: float, target_speed: float = 5.0) -> tuple[str, str]:
    cmd_yaw = (
        "MAV_CMD_CONDITION_YAW \
"
        f"param1=0 param2={yaw_rate:+.2f} param3=1 param4=1 param5=0 param6=0 param7=0"
    )
    cmd_speed = (
        "MAV_CMD_DO_CHANGE_SPEED \
"
        f"param1=1 param2={target_speed:.2f} param3=-1 param4=0 param5=0 param6=0 param7=0"
    )
    print(f"[PX4_CMD] {cmd_yaw}")
    print(f"[PX4_CMD] {cmd_speed}")
    return cmd_yaw, cmd_speed
if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(
        description='Генерація PX4-команд на основі детекційної рамки'
    )
    parser.add_argument('x1', type=float, help='ліва координата bbox (пікселі)')
    parser.add_argument('y1', type=float, help='верхня координата bbox (пікселі)')
    parser.add_argument('x2', type=float, help='права координата bbox (пікселі)')
    parser.add_argument('y2', type=float, help='нижня координата bbox (пікселі)')
    parser.add_argument('--width', type=int, default=640,
                        help='ширина кадру (пікселі)')
    parser.add_argument('--hfov', type=float, default=90.0,
                        help='горизонтальне поле зору (градуси)')
    parser.add_argument('--kp', type=float, default=0.5,
                        help='P-коефіцієнт для yaw')
    parser.add_argument('--speed', type=float, default=5.0,
                        help='цільова лінійна швидкість (м/с)')

    args = parser.parse_args()
    yaw_err, yaw_rate = compute_yaw_correction(
        args.x1, args.y1, args.x2, args.y2,
        args.width, args.hfov, args.kp
    )
    print(f"YawError = {yaw_err:+.2f}°")
    generate_px4_commands(yaw_rate, args.speed)