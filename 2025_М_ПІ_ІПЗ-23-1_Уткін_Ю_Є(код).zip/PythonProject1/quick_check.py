import torch, cv2
from ultralytics import YOLO
from deep_sort_realtime.deepsort_tracker import DeepSort

print(f"PyTorch  : {torch.__version__} | CUDA: {torch.cuda.is_available()}")
print(f"OpenCV   : {cv2.__version__}")
print(f"YOLOv8   : {YOLO}")
print(f"DeepSORT : {DeepSort}")
